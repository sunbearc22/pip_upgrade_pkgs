# Purpose: to verify that package is installed correctly.
name = 'upgrade_pip_packages'
